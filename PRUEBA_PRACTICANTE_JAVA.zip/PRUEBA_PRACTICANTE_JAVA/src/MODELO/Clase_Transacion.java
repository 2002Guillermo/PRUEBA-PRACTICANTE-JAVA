package MODELO;

public class Clase_Transacion {

    private int NUMERO_CUENTA_FK;
    private String TIPO_TRANSACION;
    private double VALOR_TRANSACION;
    private String FECHA_TRANSACION;

    public int getNUMERO_CUENTA_FK() {
        return NUMERO_CUENTA_FK;
    }

    public void setNUMERO_CUENTA_FK(int NUMERO_CUENTA_FK) {
        this.NUMERO_CUENTA_FK = NUMERO_CUENTA_FK;
    }

    public String getTIPO_TRANSACION() {
        return TIPO_TRANSACION;
    }

    public void setTIPO_TRANSACION(String TIPO_TRANSACION) {
        this.TIPO_TRANSACION = TIPO_TRANSACION;
    }

    public double getVALOR_TRANSACION() {
        return VALOR_TRANSACION;
    }

    public void setVALOR_TRANSACION(double VALOR_TRANSACION) {
        this.VALOR_TRANSACION = VALOR_TRANSACION;
    }

    public String getFECHA_TRANSACION() {
        return FECHA_TRANSACION;
    }

    public void setFECHA_TRANSACION(String FECHA_TRANSACION) {
        this.FECHA_TRANSACION = FECHA_TRANSACION;
    }

    public Clase_Transacion(int NUMERO_CUENTA_FK, String TIPO_TRANSACION, double VALOR_TRANSACION, String FECHA_TRANSACION) {
        this.NUMERO_CUENTA_FK = NUMERO_CUENTA_FK;
        this.TIPO_TRANSACION = TIPO_TRANSACION;
        this.VALOR_TRANSACION = VALOR_TRANSACION;
        this.FECHA_TRANSACION = FECHA_TRANSACION;
    }

    public Clase_Transacion(int NUMERO_CUENTA_FK, String TIPO_TRANSACION, double VALOR_TRANSACION) {
        this.NUMERO_CUENTA_FK = NUMERO_CUENTA_FK;
        this.TIPO_TRANSACION = TIPO_TRANSACION;
        this.VALOR_TRANSACION = VALOR_TRANSACION;
    }

   

}