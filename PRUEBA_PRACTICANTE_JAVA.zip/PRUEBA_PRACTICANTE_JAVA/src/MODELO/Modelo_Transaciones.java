package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Modelo_Transaciones {

    Conexion con;
    Connection C;

    public Modelo_Transaciones() {
        con = new Conexion();
        C = con.getConexion();

    }

    public int Hacer_Transacion_Abono(Clase_Transacion c) {
        int r;
        try {
            String sql = "INSERT INTO TRANSACIONES(NUMERO_CUENTA_FK, TIPO_TRANSACION, VALOR_TRANSACION)"
                    + "VALUES(?, ?, ?)";
            PreparedStatement s = C.prepareStatement(sql);
            System.out.print(c.getNUMERO_CUENTA_FK());
            s.setInt(1, c.getNUMERO_CUENTA_FK());
            s.setString(2, c.getTIPO_TRANSACION());
            s.setDouble(3, c.getVALOR_TRANSACION());
            r = s.executeUpdate();

            if (r > 0) {
                String sql2 = "UPDATE CUENTA SET SALDO_CUENTA = (SALDO_CUENTA +" + c.getVALOR_TRANSACION() + ") "
                        + "WHERE NUMERO_CUENTA = ?";
                PreparedStatement ps = C.prepareStatement(sql2);
                ps.setInt(1, c.getNUMERO_CUENTA_FK());
                r = ps.executeUpdate();
                if (r > 0) {
                    System.out.print("hola");
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error: " + ex);
            r = 0;
        }
        return r;
    }

    public int Hacer_Transacion_Retiro(Clase_Transacion c) {
        int r = 0;
        try {
            String buscar = "SELECT (SALDO_CUENTA - " +c.getVALOR_TRANSACION()+ ") "
                    + "AS TOTAL FROM CUENTA WHERE NUMERO_CUENTA = ?";
            PreparedStatement s = C.prepareStatement(buscar);
            s.setInt(1, c.getNUMERO_CUENTA_FK());
            ResultSet rs = s.executeQuery();
            if (rs.next()) {
                String sql = "INSERT INTO TRANSACIONES(NUMERO_CUENTA_FK, TIPO_TRANSACION, VALOR_TRANSACION)"
                        + "VALUES(?, ?, ?)";
                PreparedStatement p = C.prepareStatement(sql);
                System.out.print(c.getNUMERO_CUENTA_FK());
                p.setInt(1, c.getNUMERO_CUENTA_FK());
                p.setString(2, c.getTIPO_TRANSACION());
                p.setDouble(3, c.getVALOR_TRANSACION());
                r = p.executeUpdate();
                if (r > 0) {
                    String sql2 = "UPDATE CUENTA SET SALDO_CUENTA = (SALDO_CUENTA -" + c.getVALOR_TRANSACION() + ") "
                            + "WHERE NUMERO_CUENTA = ?";
                    PreparedStatement ps = C.prepareStatement(sql2);
                    ps.setInt(1, c.getNUMERO_CUENTA_FK());
                    r = ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Transacion Exitosa, Se Retiro Correctamente");
                } else {
                    JOptionPane.showMessageDialog(null, "Error Al Hacer Transacion");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Saldo Insufiente Para La Transacion");
            }
        } catch (SQLException ex) {
            System.err.println("Error: " + ex);
            r = 0;
        }
        return r;
    }

    public String[] Historial_Transaciones(int NUMERO_CUENTA_FK) {
        String datos[] = new String[3];
        datos[0] = "null";
        try {
            String buscar = "SELECT * FROM Transaciones WHERE NUMERO_CUENTA_FK = ? ";
            PreparedStatement s = C.prepareStatement(buscar);
            s.setInt(1, NUMERO_CUENTA_FK);
            ResultSet rs = s.executeQuery();
            if (rs.next()) {
                datos[0] = rs.getString("ID_TRANSACIONES");
                datos[1] = rs.getString("NUMERO_CUENTA_FK");
                datos[1] = rs.getString("TIPO_TRANSACION");
                datos[1] = rs.getString("VALOR_TRANSACION");
                datos[1] = rs.getString("FECHA_TRANSACION");
            } else {
                JOptionPane.showMessageDialog(null, "No Se Encontro La Cuenta");
            }
        } catch (SQLException ex) {
            System.err.println("Error: " + ex);
        }
        return datos;
    }
}
