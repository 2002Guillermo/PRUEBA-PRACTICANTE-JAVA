package MODELO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Model_Cuenta {

    Conexion con;
    Connection C;

    public Model_Cuenta() {

        con = new Conexion();
        C = con.getConexion();
    }

    public int Crear_Cuenta(Clase_Cuenta c) {
        int r;
        try {
            
            String Insertar = "INSERT INTO CUENTA "
                        + "(SALDO_CUENTA, TITULAR_CUENTA)"
                        + "VALUES"
                        + "(?,?)";
            PreparedStatement ps = C.prepareStatement(Insertar);
            ps.setDouble(1, c.getSALDO_CUENTA());
            ps.setString(2, c.getTITULAR_CUENTA());
            r = ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.print("Error " + ex);
            r = 0;
        }
        return r;
    }
    public String[] Buscar_Cuenta(int DOCUMENTO ){
        String datos[] = new String[2];
        datos[0] = "null";
        try {
            String buscar = "SELECT * FROM CUENTA WHERE NUMERO_CUENTA = ? ";
            PreparedStatement s = C.prepareStatement(buscar);
            s.setInt(1, DOCUMENTO);
            ResultSet rs = s.executeQuery();
            if (rs.next()) {
                datos[0] = rs.getString("TITULAR_CUENTA");
                datos[1] = rs.getString("SALDO_CUENTA");
            } else {
                JOptionPane.showMessageDialog(null, "No Se Encontro La Cuenta");
            }
        } catch (SQLException ex) {
            System.err.println("Error: " + ex);
        }
        return datos;
    }
}


