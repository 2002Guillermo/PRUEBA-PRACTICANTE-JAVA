package CONTTROLADOR;

import MODELO.Clase_Cuenta;
import MODELO.Model_Cuenta;
import VISTA.Vista_Cuenta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Controlador_Cuenta implements ActionListener {

    Vista_Cuenta formCuenta;

    public Controlador_Cuenta(Vista_Cuenta formCuenta) {
        this.formCuenta = formCuenta;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(formCuenta.btnGuardar)) {
            if (!formCuenta.txtTitular.getText().equals("") && !formCuenta.txtSaldoImportado.getText().equals("")) {
                int SALDO_CUENTA = Integer.parseInt(formCuenta.txtSaldoImportado.getText());
                String TITULAR_CUENTA = formCuenta.txtTitular.getText();
                Clase_Cuenta datos = new Clase_Cuenta(SALDO_CUENTA, TITULAR_CUENTA);
                Model_Cuenta Mdl = new Model_Cuenta();
                int respuesta = Mdl.Crear_Cuenta(datos);
                if (respuesta > 0) {
                    JOptionPane.showMessageDialog(null, "Cuenta Creada Satisfactoriamente");
                    formCuenta.txtTitular.setText(null);
                    formCuenta.txtSaldoImportado.setText(null);
                } else {
                    JOptionPane.showMessageDialog(null, "Error Al Crear Cuenta");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe Completar Los Campos Para Crear La cuenta");
            }
        } else if (e.getSource().equals(formCuenta.btnbuscar)) {
            if (!formCuenta.txtBuscar.getText().equals("")) {
                int NUMERO_CUENTA = Integer.parseInt(formCuenta.txtBuscar.getText());
                Model_Cuenta Mdl = new Model_Cuenta();
                String datos[] = Mdl.Buscar_Cuenta(NUMERO_CUENTA);
                formCuenta.txtTitular.setText(datos[0]);
                formCuenta.txtSaldoImportado.setText(datos[1]);
            } else {
                JOptionPane.showMessageDialog(null, "Debe Completar El Campos Para Buscar La cuenta");
            }
        }
    }
}