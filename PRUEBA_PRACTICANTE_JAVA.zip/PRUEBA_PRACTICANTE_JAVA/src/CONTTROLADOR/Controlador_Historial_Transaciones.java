
package CONTTROLADOR;

import MODELO.Clase_Transacion;
import MODELO.Modelo_Historial_transaciones;
import VISTA.Vista_Historial_Transaciones;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Controlador_Historial_Transaciones implements ActionListener {

    Vista_Historial_Transaciones vstHistorial;
    DefaultTableModel tabla;

    public Controlador_Historial_Transaciones(Vista_Historial_Transaciones vstHistorial) {
        this.vstHistorial = vstHistorial;
        tabla = new DefaultTableModel();
        String[] titulo = {"NUMERO_CUENTA", "TIPO_TRANSACION", "VALOR_TRANSACION", "FECHA_TRANSACION"};
        tabla.setColumnIdentifiers(titulo);
        vstHistorial.tablaHistorial.setModel(tabla);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(vstHistorial.btnBuscar)) {
            if (!vstHistorial.txtBuscarCuenta.getText().equals("")) {
                int Numero_Cuenta = Integer.parseInt(vstHistorial.txtBuscarCuenta.getText());
                Modelo_Historial_transaciones mdl = new Modelo_Historial_transaciones();
                LinkedList<Clase_Transacion> L = mdl.Historial_Transaciones_Cuenta(Numero_Cuenta);
                String c[] = new String[4];
                for (Clase_Transacion fila : L) {
                    c[0] = String.valueOf(fila.getNUMERO_CUENTA_FK());
                    c[1] = String.valueOf(fila.getTIPO_TRANSACION());
                    c[2] = String.valueOf(fila.getVALOR_TRANSACION());
                    c[3] = fila.getFECHA_TRANSACION();
                    tabla.addRow(c);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Debe Completar El Campo Para Hacer La Busqueda");
            }
        }
    }

}
