package CONTTROLADOR;

import MODELO.Clase_Cuenta;
import MODELO.Clase_Transacion;
import MODELO.Modelo_Transaciones;
import VISTA.Vista_Hacer_Transacion;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class Controlador_Hacer_Transaciones implements ActionListener {

    Vista_Hacer_Transacion FrmTransaciones;

    public Controlador_Hacer_Transaciones(Vista_Hacer_Transacion FrmTransaciones) {
        this.FrmTransaciones = FrmTransaciones;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().equals(FrmTransaciones.btnAceptar)) {
            if (!FrmTransaciones.txtN_Cuenta.getText().equals("") && !FrmTransaciones.txtValor_Transacion.getText().equals("")) {
                int NUMERO_CUENTA = Integer.parseInt(FrmTransaciones.txtN_Cuenta.getText());
                double VALOR_TRANSACION = Double.parseDouble(FrmTransaciones.txtValor_Transacion.getText());
                String TIPO_TRANSACION;
                if (FrmTransaciones.Abono.isSelected()) {
                    Clase_Transacion datos = new Clase_Transacion(NUMERO_CUENTA, "Abono", VALOR_TRANSACION);
                    Modelo_Transaciones mdl = new Modelo_Transaciones();
                    int respuesta = mdl.Hacer_Transacion_Abono(datos);
                    if (respuesta > 0) {
                        JOptionPane.showMessageDialog(null, "Se Hizo La Transaccion Exitosamente, Se Abono El Dinero A La Cuenta");
                        FrmTransaciones.txtN_Cuenta.setText("");
                        FrmTransaciones.txtValor_Transacion.setText("");
                    } else {
                        JOptionPane.showMessageDialog(null, "Error Al Hacer Transaccion");
                    }
                } else if (FrmTransaciones.Retiro.isSelected()) {
                    Clase_Transacion d = new Clase_Transacion(NUMERO_CUENTA, "Retiro", VALOR_TRANSACION);
                    Modelo_Transaciones md = new Modelo_Transaciones();
                    int r = md.Hacer_Transacion_Retiro(d);
                    if (r > 0) {
                        JOptionPane.showMessageDialog(null, "Se Hizo La Transaccion Exitosamente, Se Retiro El Dinero A La Cuenta");
                        FrmTransaciones.txtN_Cuenta.setText("");
                        FrmTransaciones.txtValor_Transacion.setText("");
                    }
                }
            } else {
                JOptionPane.showMessageDialog(null, "No Deben Haber Campos Para La Actualizacion");
            }
        } else if (e.getSource().equals(FrmTransaciones.btnCancelar)) {
            int a = JOptionPane.showConfirmDialog(null, "¿Deseas Cancelar La Transaccion?", "¿Esta Seguro?",
                        JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (a == 0) {
                JOptionPane.showMessageDialog(null, "Transaccion Cancelaada");
                FrmTransaciones.txtN_Cuenta.setText("");
                FrmTransaciones.txtValor_Transacion.setText("");
            }
        }
    }
}
